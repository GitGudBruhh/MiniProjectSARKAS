#!/bin/sh

echo "rm -f dbscan_*.out hac_*.out mb_*.csv process_mb.log full.csv"
      rm -f dbscan_*.out hac_*.out mb_*.csv process_mb.log full.csv
