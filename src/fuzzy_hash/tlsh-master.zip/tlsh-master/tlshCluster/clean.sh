#!/bin/sh

echo "rm -rf __pycache__ pylib/__pycache__"
      rm -rf __pycache__ pylib/__pycache__


